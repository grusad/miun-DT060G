/*
* Filename:		Main.cpp
* Course:		Objectorienterad Programmering i C++
* Author:		Alexander Gillberg
* ID:			algi1701
*/


#include "TestProgram.h"


int main() {
	

	TestProgram p;
	p.runStart();


}