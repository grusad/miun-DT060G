/*
* Filename:		Main.cpp
* Course:		DT019G Objectorienterad Programmering i C++
* Author:		Alexander Gillberg
* ID:			algi1701
* Date:			2018-03-26
*/


#include "TestApp.h"

#include <iostream>
int main() {

	TestApp app;
	app.run();


	std::cin.get();
}